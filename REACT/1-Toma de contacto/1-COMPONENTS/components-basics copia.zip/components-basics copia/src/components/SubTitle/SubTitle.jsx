import "./SubTitle.css/";

export const SubTitle = () => {
  return <h2>This is a example components with ReactJS </h2>;
};
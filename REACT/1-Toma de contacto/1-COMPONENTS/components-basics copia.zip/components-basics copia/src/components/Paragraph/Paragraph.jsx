import "./Paragraph.css/";

export const Paragraph = () => {
  return <p>Hakuna Matata, vive y se feliz</p>;
};
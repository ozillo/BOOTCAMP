import "./Image.css/";

export const Image = () => {
  return (
    <img
      src="https://fastly.picsum.photos/id/397/200/200.jpg?hmac=3VBYe8NBAUuvEizTQB0-d8wp2jgqMblJK8vH3h8cslE"
      alt="Random"
    />
  );
};
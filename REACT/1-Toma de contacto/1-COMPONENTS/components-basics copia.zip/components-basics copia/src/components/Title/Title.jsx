import "./Title.css";


export const Title = () => {

return <h1>Welcome to Components ReactJS</h1>;


};